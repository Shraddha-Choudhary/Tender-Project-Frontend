import React from "react";

function Login() {
  return (
    <div className="flex h-screen items-center justify-center bg-gray-900">
      <div className="h-[80%] w-[90%] max-w-4xl bg-slate-100 flex items-center justify-center relative">
        {/* Decorative Elements */}
        <div className="absolute bottom-[-1rem] left-[-1rem] w-36 h-36 bg-yellow-500 rounded-full opacity-70"></div>
        <div className="absolute top-[-1rem] right-[-2rem] w-36 h-36 bg-red-500 rounded-full opacity-50 shadow-lg"></div>

        <div className="flex w-full m-4 bg-white rounded-lg shadow-lg">
          {/* Left Section */}
          <div className="w-full md:w-1/3 bg-gradient-to-br from-green-400 to-teal-700 p-8 text-white flex flex-col justify-center items-center">
            <h1 className="text-3xl font-bold mb-4 text-center">
              Welcome Back!
            </h1>
            <p className="mb-8 text-center text-sm font-light">
              To keep connected with us, login <br></br>with your personal info
            </p>
            <button className="border-2 border-white py-2 px-8 rounded-full hover:bg-white hover:text-teal-500 transition">
              SIGN IN
            </button>
          </div>

          {/* Right Section */}
          <div className="w-full md:w-1/2 p-6 ml-16">
            <h2 className="text-2xl font-bold text-teal-500 mb-6 text-center">
              Create Account
            </h2>
            <div className="flex justify-center space-x-4 mb-8">
              <button className="w-10 h-10 flex items-center justify-center bg-gray-100 rounded-full shadow-md hover:bg-gray-300 transition">
                <i className="fab fa-facebook-f text-black text-sm"></i>
              </button>
              <button className="w-10 h-10 flex items-center justify-center bg-gray-100 rounded-full shadow-md hover:bg-gray-300 transition">
                <i className="fab fa-google text-black text-sm"></i>
              </button>
              <button className="w-10 h-10 flex items-center justify-center bg-gray-100 rounded-full shadow-md hover:bg-gray-300 transition">
                <i className="fab fa-linkedin-in text-black text-sm"></i>
              </button>
            </div>
            <p className="text-center text-gray-500 mb-4">
              or use your email for registration:
            </p>
            <form className="space-y-4">
              <input
                type="text"
                placeholder="Name"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
              <input
                type="email"
                placeholder="Email"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
              <input
                type="password"
                placeholder="Password"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
              <button
                type="submit"
                className="w-36 py-2 ml-28 bg-gradient-to-r from-teal-500 to-green-400 text-white rounded-full font-medium hover:bg-gradient-to-1 transition duration-300"
              >
                SIGN UP
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Login;
