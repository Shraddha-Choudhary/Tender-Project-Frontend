// import { useEffect, useState } from "react";
// import axios from "axios";

// function AdmissionsList() {
//   const [data, setData] = useState([]);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     // async function banayi taki try-catch me API call kar sake
//     const fetchAdmissions = async () => {
//       try {
//         const res = await axios.get(
//           "https://school-backend-1-utv3.onrender.com/api/admissions?page=1&limit=10"
//         );

//         console.log("Fetched data:", res.data);
//         setData(res.data.data || []); // backend ke response ka data part
//       } catch (err) {
//         console.error("Fetch error:", err);
//       } finally {
//         setLoading(false); // loading ko false karna chahe success ho ya error
//       }
//     };

//     fetchAdmissions();
//   }, []);

//   if (loading) return <p>Loading...</p>;

//   return (
//     <div className="p-4">
//       <h2 className="text-xl font-bold">Admissions</h2>
//       {data.length === 0 ? (
//         <p>No admissions found.</p>
//       ) : (
//         <ul>
//           {data.map((item) => (
//             <li key={item._id} className="border p-2 m-2">
//               <p>
//                 <b>Child Name:</b> {item.childName}
//               </p>
//               <p>
//                 <b>Parent Name:</b> {item.parentName}
//               </p>
//               <p>
//                 <b>Status:</b> {item.status}
//               </p>
//             </li>
//           ))}
//         </ul>
//       )}
//     </div>
//   );
// }

// export default AdmissionsList;





// import { useEffect, useState } from "react";
// import axios from "axios";

// function AdmissionsList() {
//   const [enquiries, setEnquiries] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);

//   useEffect(() => {
//     const fetchEnquiries = async () => {
//       try {
//         setLoading(true);
//         const token = localStorage.getItem("token"); // ✅ token from login
//         if (!token) {
//           setError("No token found. Please login first.");
//           setLoading(false);
//           return;
//         }

//         const res = await axios.get(
//           "https://school-backend-1-utv3.onrender.com/api/enquiries?page=1&limit=5",
//           {
//             headers: {
//               Authorization: `Bearer ${token}`, // ✅ send token to backend
//             },
//           }
//         );

//         setEnquiries(res.data.data || []);
//       } catch (err) {
//         setError(err.response?.data?.message || "Error fetching enquiries");
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchEnquiries();
//   }, []);

//   return (
//     <div style={{ padding: "20px" }}>
//       <h2>📩 Enquiries List</h2>

//       {loading && <p>Loading enquiries...</p>}
//       {error && <p style={{ color: "red" }}>{error}</p>}

//       {!loading && !error && enquiries.length === 0 && (
//         <p>No enquiries found.</p>
//       )}

//       {!loading && !error && enquiries.length > 0 && (
//         <ul>
//           {enquiries.map((e) => (
//             <li key={e._id} style={{ marginBottom: "10px" }}>
//               <strong>{e.name}</strong> - {e.email} <br />
//               <em>{e.message}</em>
//             </li>
//           ))}
//         </ul>
//       )}
//     </div>
//   );
// }

// export default AdmissionsList;



import { useEffect, useState } from "react";
import {
  getAllAdmissions,
  deleteAdmission,
} from "./AdmissionService";

function AdmissionsList() {
  const [admissions, setAdmissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const fetchAdmissions = async () => {
    try {
      setLoading(true);
      const res = await getAllAdmissions({ page, limit: 5 });
      setAdmissions(res.data.data);
      setTotalPages(res.data.totalPages);
    } catch (err) {
      console.error("Error fetching admissions:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Delete this admission?")) {
      await deleteAdmission([id]);
      fetchAdmissions();
    }
  };

  useEffect(() => {
    fetchAdmissions();
  }, [page]);

  if (loading) return <p className="text-center">Loading...</p>;

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Admissions List</h2>
      <table className="w-full border">
        <thead>
          <tr className="bg-gray-200">
            <th className="p-2">Child</th>
            <th className="p-2">Parent</th>
            <th className="p-2">Status</th>
            <th className="p-2">Image</th>
            <th className="p-2">Actions</th>
          </tr>
        </thead>
        <tbody>
          {admissions.map((adm) => (
            <tr key={adm._id} className="border-b">
              <td className="p-2">{adm.childName}</td>
              <td className="p-2">{adm.parentName}</td>
              <td className="p-2">{adm.status}</td>
              <td className="p-2">
                {adm.image && (
                  <img src={adm.image} alt="admission" className="h-12" />
                )}
              </td>
              <td className="p-2">
                <button
                  onClick={() => handleDelete(adm._id)}
                  className="px-3 py-1 bg-red-500 text-white rounded"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Pagination */}
      <div className="flex gap-2 mt-4">
        <button
          disabled={page === 1}
          onClick={() => setPage((p) => p - 1)}
          className="px-3 py-1 bg-gray-300 rounded disabled:opacity-50"
        >
          Prev
        </button>
        <span>
          Page {page} of {totalPages}
        </span>
        <button
          disabled={page === totalPages}
          onClick={() => setPage((p) => p + 1)}
          className="px-3 py-1 bg-gray-300 rounded disabled:opacity-50"
        >
          Next
        </button>
      </div>
    </div>
  );
}

export default AdmissionsList;
