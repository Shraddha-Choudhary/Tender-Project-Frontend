import { useState } from "react";
import { createAdmission, updateAdmission } from "./AdmissionService";

function AdmissionForm({ editData, onSuccess }) {
  const [form, setForm] = useState({
    childName: editData?.childName || "",
    parentName: editData?.parentName || "",
    status: editData?.status || "Pending",
  });
  const [image, setImage] = useState(null);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    Object.keys(form).forEach((key) => formData.append(key, form[key]));
    if (image) formData.append("image", image);

    if (editData) {
      await updateAdmission(editData._id, formData);
      alert("Admission updated!");
    } else {
      await createAdmission(formData);
      alert("Admission created!");
    }

    if (onSuccess) onSuccess();
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 border rounded space-y-4">
      <input
        type="text"
        name="childName"
        value={form.childName}
        onChange={handleChange}
        placeholder="Child Name"
        className="w-full border p-2"
      />
      <input
        type="text"
        name="parentName"
        value={form.parentName}
        onChange={handleChange}
        placeholder="Parent Name"
        className="w-full border p-2"
      />
      <select
        name="status"
        value={form.status}
        onChange={handleChange}
        className="w-full border p-2"
      >
        <option value="Pending">Pending</option>
        <option value="Approved">Approved</option>
      </select>
      <input type="file" onChange={(e) => setImage(e.target.files[0])} />
      <button className="bg-blue-500 text-white px-4 py-2 rounded">
        {editData ? "Update" : "Create"}
      </button>
    </form>
  );
}

export default AdmissionForm;
