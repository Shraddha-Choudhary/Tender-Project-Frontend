import axios from "axios";


// ✅ Base URL
const API_URL = "https://school-backend-1-utv3.onrender.com/api";

// ✅ Create Admission
export const createAdmission = async (formData) => {
  return await axios.post(`${API_URL}/admission`, formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};

// ✅ Get All Admissions
export const getAllAdmissions = async (params) => {
  return await axios.get(`${API_URL}/admissions`, { params });
};

// ✅ Get Single Admission
export const getAdmission = async (id) => {
  return await axios.get(`${API_URL}/admission/${id}`);
};

// ✅ Update Admission
export const updateAdmission = async (id, formData) => {
  return await axios.patch(`${API_URL}/admission/${id}`, formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};

// ✅ Delete Admission(s)
export const deleteAdmission = async (ids) => {
  return await axios.delete(`${API_URL}/admissions`, { data: { ids } });
};

// ✅ Get Total Admissions Count
export const getTotalAdmissions = async () => {
  return await axios.get(`${API_URL}/totalAdmissions`);
};
