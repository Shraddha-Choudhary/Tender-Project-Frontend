import React from "react";
import AdmissionsList from "./Components/AdmissionsList";
import AdmissionForm from "./Components/AdmissionForm";


function App() {
  return (
    <div>
      {/* <Login /> */}

      <AdmissionsList/>
      <AdmissionForm/>
    </div>
  );
}
export default App;
